CloneX_Base is an SFX archive that includes .arexport/.arproj files and .js files for correct settings. 
Each .arexport and .arproj file is responsible for a specific detail of the clone (eyes, hair, smile, etc.). 

All you need to do is start Spark AR and run CloneX_Base. 
Then you add your clone's 3D files and CloneX_Base automatically installs them in the desired location. 

As a result, you have a ready filter with all the settings and all you have to do is to download it and publish it to Instagram.
